// Copyright (c) 2026 Artyom Lazyan. All rights reserved.
// SPDX-License-Identifier: LicenseRef-SwarmKit-Proprietary
//
// This file is part of SwarmKit.
// See LICENSE.md in the repository root for full license terms.

#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

#include "swarmkit/core/clock_quality.h"
#include "swarmkit/core/evidence_record.h"
#include "swarmkit/core/evidence_store.h"
#include "swarmkit/core/state_quality_contract.h"

namespace swarmkit::core {

/// Participant snapshot bound into the acceptance decision (§8).
struct ParticipantSnapshot {
    /// Resolved participant set I* at the time of the request.
    std::vector<std::string> agent_ids;
    /// Membership revision v_I.
    std::uint64_t membership_revision{0};

    bool operator==(const ParticipantSnapshot&) const = default;
};

/// Snapshot request context fixing both t* and r* (§8).
///
/// t* = physical/reference-domain evaluation time.
/// r* = runtime evidence-freeze cutoff: only evidence with receive_time ≤ r*
///      can influence the decision.
struct SnapshotRequestContext {
    /// Physical evaluation time t* (reference domain, Unix ms).
    double evaluation_time_ms{};
    /// Evidence-freeze cutoff r* (reference domain, Unix ms).
    /// Only evidence records with receive_time ≤ r* are eligible.
    std::int64_t evidence_freeze_ms{};
    /// Resolved participant snapshot at request time.
    ParticipantSnapshot participants;
};

/// Rejection reason for a single predicate failure (§47).
enum class RejectionReason : std::uint8_t {
    kMissingRequiredEvidence,
    kCausalSampleUnavailable,
    kAgeExceeded,
    kClockUncertaintyExceeded,
    kStateUncertaintyExceeded,
    kEstimatorUnhealthy,
    kFrameMismatch,
    kStaleAgentEpoch,
    kMissionRevisionMismatch,
    kProvenanceMismatch,
    kIncompleteAgentSet,
    kUnsupportedUncertaintySemantics,
    kMissingClockQuality,
    kMissingSourceTimestamp,
    kInvalidContract,
    kMissingUncertainty,
    kUncertaintySemanticsMismatch,
    kInvalidUncertaintyBound,
    kUnsupportedPropagationFrame,
    kInvalidClockBound,
    kGpsQualityInsufficient,
};

/// One predicate failure with context.
struct PredicateFailure {
    RejectionReason reason{};
    std::string agent_id;
    EvidenceFieldId field{};
    std::string detail;
};

/// Primitive clock-model operands used to map one selected source timestamp
/// into the runtime reference domain.  These values are captured at selection
/// time so certificates never reconstruct or invent the clock model later.
struct ClockEvaluationEvidence {
    double theta_hat_ms{};
    double base_rho_ms{};
    double effective_rho_ms{};
    double max_drift_rate_ppm{};
    std::int64_t model_last_update_reference_ms{};
    std::string model_version;
    std::string agent_incarnation_id;
    ClockDomain source_domain{ClockDomain::kUnknown};
    ClockSynchronization synchronization{ClockSynchronization::kUnknown};
    bool deterministic_bound{false};

    bool operator==(const ClockEvaluationEvidence&) const = default;
};

/// Accepted evidence state for one agent and one field.
struct AcceptedFieldState {
    /// The evidence record that was accepted.
    EvidenceRecord evidence;

    /// Generation-time interval in reference domain [g⁻, g⁺].
    GenerationTimeInterval generation_interval;

    /// Conservative elapsed time Δ⁺ = t* - g⁻ in milliseconds.
    double conservative_elapsed_ms{};

    /// Observation-time uncertainty e_p (from the estimator).
    double observation_uncertainty{};

    /// Propagated uncertainty ε(t*) = e_p + V_max · Δ⁺ (§9 Eq.10).
    double propagated_uncertainty{};

    /// Exact clock-model operands used for this evidence item.
    ClockEvaluationEvidence clock_evaluation;
};

/// Complete accepted multi-UAV snapshot at a common evaluation time.
struct AcceptedSnapshot {
    /// Unique snapshot identifier.
    std::string snapshot_id;

    /// Common evaluation time t* (§8).
    double evaluation_time_ms{};

    /// Evidence-freeze cutoff r* (§8).
    std::int64_t evidence_freeze_ms{};

    /// Contract that was satisfied.
    std::string contract_id;
    std::uint32_t contract_version{};
    std::string contract_hash;

    /// Propagation model binding (§14 item M).
    std::string model_id;
    std::string model_version;

    /// Resolved participant snapshot at request time.
    ParticipantSnapshot participants;

    /// Per-agent, per-field accepted state.
    /// Key: agent_id → field_id → AcceptedFieldState
    std::unordered_map<std::string,
                       std::unordered_map<std::uint8_t, AcceptedFieldState>>
        agent_states;

    /// Agents that contributed to this snapshot.
    std::vector<std::string> accepted_agents;

    /// Timestamp when the snapshot was produced (reference clock, Unix ms).
    std::int64_t produced_at_ms{};
};

/// Structured rejection result with per-predicate failure details.
struct StructuredRejection {
    /// Evaluation time that was requested.
    double evaluation_time_ms{};

    /// Evidence-freeze cutoff r* that was requested.
    std::int64_t evidence_freeze_ms{};

    /// Contract that could not be satisfied.
    std::string contract_id;

    /// All predicate failures that prevented acceptance.
    std::vector<PredicateFailure> failures;
};

/// Result of a state acceptance request: either an accepted snapshot
/// or a structured rejection.  There is no third state — the runtime
/// never returns "accepted with warnings" (§11: no silent downgrade).
using AcceptanceResult = std::variant<AcceptedSnapshot, StructuredRejection>;

/// Configuration for the state acceptance engine.
struct AcceptanceEngineConfig {
    bool generate_snapshot_ids{true};
};

/// State Acceptance Engine (§8–§12, §19.3).
///
/// The engine receives a contract C and evaluation time t*, selects
/// causally eligible evidence, propagates uncertainty to t*, evaluates
/// all mandatory contract predicates, and returns ACCEPTED or REJECTED.
///
/// Mathematically pure and stateless: identical inputs produce identical decisions.
class StateAcceptanceEngine {
   public:
    explicit StateAcceptanceEngine(AcceptanceEngineConfig config = {});

    /// Request a multi-UAV state snapshot satisfying contract C at time t*
    /// with evidence-freeze cutoff r*.
    ///
    /// @param contract    State-Quality Contract defining requirements.
    /// @param request_ctx Snapshot request context with t*, r*, participants.
    /// @param evidence    Evidence store containing per-agent observations.
    /// @param clock_states Per-agent clock quality state
    ///                     keyed by (agent_id) with incarnation binding.
    /// @return AcceptedSnapshot on success, StructuredRejection on failure.
    [[nodiscard]] AcceptanceResult RequestSnapshot(
        const StateQualityContract& contract,
        const SnapshotRequestContext& request_ctx,
        const EvidenceStore& evidence,
        const std::unordered_map<std::string, ClockQualityState>& clock_states)
        const;

   private:
    AcceptanceEngineConfig config_;

    /// Select the best causal evidence for one agent and one field.
    struct EvidenceSelection {
        EvidenceRecord record;
        GenerationTimeInterval generation_interval;
        ClockEvaluationEvidence clock_evaluation;
    };

    [[nodiscard]] std::optional<EvidenceSelection> SelectCausalEvidence(
        const StateQualityContract& contract,
        const EvidenceStore& evidence,
        const std::string& agent_id,
        EvidenceFieldId field,
        const SnapshotRequestContext& request_ctx,
        const std::unordered_map<std::string, ClockQualityState>& clock_states,
        const std::string& current_session_id,
        std::vector<PredicateFailure>& failures)
        const;

    /// Evaluate a single field's evidence against the contract.
    [[nodiscard]] std::optional<PredicateFailure> EvaluateFieldPredicates(
        const StateQualityContract& contract,
        const std::string& agent_id,
        EvidenceFieldId field,
        const EvidenceSelection& selection,
        double evaluation_time_ms,
        double propagated_uncertainty,
        const std::string& current_session_id) const;
};

}  // namespace swarmkit::core
