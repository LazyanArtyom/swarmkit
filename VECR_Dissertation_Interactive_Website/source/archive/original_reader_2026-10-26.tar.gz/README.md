# VECR Research Atlas — Interactive Dissertation Reader

An offline, interactive HTML edition of the attached research manuscript:

**A Multi-User Software System for Mission Engineering, Execution Verification, and Management of Self-Organizing UAV Swarms** — Artyom Lazyan, October 2026.

## Open the website

1. Extract the ZIP into a folder.
2. Double-click **`index.htm`** (or right-click → Open with Chrome, Firefox, Edge, Safari).
3. Keep the `assets/` folder next to `index.htm`.

**No web server, internet connection, installation, Python or Node.js is needed to read the website.** Figures, math rendering, and animations are local. External links in the manuscript naturally require internet access.

## What is included

- 16 complete main research chapters, plus appendices and the original manuscript material.
- **177 LaTeX expressions pre-rendered as SVG vectors** (45 display equations plus 132 inline expressions). No runtime LaTeX CDN or network fetch is required.
- 8 vector diagrams generated from the original Mermaid diagram definitions; each figure can be enlarged and its original definition inspected.
- Original generated drone concept artwork and an interactive four-state A→B edge-surveying demonstration.
- Responsive layout, collapsible chapter navigation, chapter/text search, light/dark themes, adjustable font size, reading progress, and print-friendly styles.
- Original, unmodified Markdown under `source/dissertation.md`.
- `assets/math-index.json` and `assets/research-metadata.json` for traceability, if you need to update or rebuild the reader in the future.

## File structure

```text
index.htm
README.md
assets/
  style.css
  site.js
  math-index.json
  research-metadata.json
  diagrams/
    research-diagram-01.svg ... research-diagram-08.svg
  images/
    swarm-flight-concept.webp
    favicon.svg
source/
  dissertation.md
```

## Research-status safeguard

This viewer faithfully converts the supplied research manuscript. **VECR is described as a proposed scientific method that still requires experimental validation.** The project does not imply experiments have already been performed or that the cloud SaaS has already been fully deployed. Earlier established rotor-router/gossip mathematics is distinguished from proposed VECR verification and recovery semantics.

## Equations

The original Markdown used the `\(...\)` and `\[...\]` LaTeX delimiters. Many Markdown viewers treat those as plain text, producing the broken notation shown in the report. This website renders every mathematical expression at build time to inline vector SVG, avoiding dependence on a Markdown math extension.

The `Copy LaTeX` control retrieves the exact original equation directly from the HTML page's embedded equation index (so it works offline on browsers that permit clipboard access). You can always find the untouched equations in `source/dissertation.md`.

## Generated artwork and diagrams

- Diagram SVGs are editable/reusable local assets.
- The decorative drone image is concept art, **not** an image of an experiment, testbed or verified results.
- The interactive scene illustrates a hypothetical edge-execution scenario; percentages are illustrative and **not measured dissertation statistics**.

## Implementation notes

The website was generated from the uploaded Markdown without changing its scientific assertions. MathJax was used during generation only; it does not need to be bundled or downloaded to view the result. Graphviz was used to convert Mermaid graph syntax to local vector figures. The custom sequence diagrams and interactive animation use locally included SVG and JavaScript.
