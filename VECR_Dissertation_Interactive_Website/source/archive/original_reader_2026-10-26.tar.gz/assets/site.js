(()=>{
'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const metaUrl='assets/research-metadata.json';
const mathUrl='assets/math-index.json';
const toast=$('#toast');let toastT;
const note=s=>{toast.textContent=s;toast.classList.add('visible');clearTimeout(toastT);toastT=setTimeout(()=>toast.classList.remove('visible'),2200)};
const navChapters=$$('.nav-chapter');
navChapters.forEach(c=>c.querySelector('.nav-primary')?.addEventListener('click',()=>{navChapters.forEach(z=>{if(z!==c)z.classList.remove('expanded')});c.classList.toggle('expanded',true)}));
const allHeaders=$$('#manuscript h1, #manuscript h2');
const allNavLinks=$$('.sidebar-nav a');
let scheduled=false;
function updateScroll(){scheduled=false;const documentH=document.documentElement.scrollHeight-innerHeight;$('#readProgress').style.width=(documentH>0?Math.max(0,Math.min(100,scrollY/documentH*100)):0)+'%';let active=null;for(const h of allHeaders){if(h.getBoundingClientRect().top<130)active=h;else break;}if(active){const target=allNavLinks.find(a=>a.getAttribute('href')==='#'+active.id);if(target){allNavLinks.forEach(x=>x.classList.toggle('active',x===target));target.closest('.nav-chapter')?.classList.add('expanded')}}}
window.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(updateScroll)}},{passive:true});updateScroll();
const mobile=$('#mobileToc');mobile.addEventListener('click',()=>$('#sidebar').classList.toggle('open'));allNavLinks.forEach(a=>a.addEventListener('click',()=>$('#sidebar').classList.remove('open')));
function setTheme(mode){document.documentElement.dataset.theme=mode;$('#themeToggle').textContent=mode==='dark'?'☼':'☾';try{localStorage.setItem('vecr-theme',mode)}catch(e){}}
try{setTheme(localStorage.getItem('vecr-theme')||'dark')}catch(e){setTheme('dark')}
$('#themeToggle').addEventListener('click',()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));
let fontSize=1;try{fontSize=Number(localStorage.getItem('vecr-font'))||1}catch(e){}
const updateFont=()=>{document.documentElement.style.setProperty('--font-scale',fontSize);try{localStorage.setItem('vecr-font',fontSize)}catch(e){}};updateFont();
$('#fontIncrease').addEventListener('click',()=>{fontSize=Math.min(1.28,Math.round((fontSize+.06)*100)/100);updateFont();note('Text size adjusted')});
$('#fontDecrease').addEventListener('click',()=>{fontSize=Math.max(.86,Math.round((fontSize-.06)*100)/100);updateFont();note('Text size adjusted')});
const search=$('#chapterSearch'),results=$('#searchResults');
const manuscript=$('#manuscript');const searchable=$$('#manuscript h1,#manuscript h2,#manuscript h3,#manuscript p');
search.addEventListener('input',()=>{
 const q=search.value.trim().toLowerCase();if(q.length<2){results.hidden=true;results.innerHTML='';return;}
 const scored=[];let lastSection='';for(const el of searchable){if(el.matches('h1,h2,h3'))lastSection=el.id||lastSection;
 const text=(el.textContent||'').replace(/\s+/g,' ').trim();const n=text.toLowerCase().indexOf(q);if(n>=0){scored.push({id:el.id||lastSection||'manuscriptStart',title:el.matches('h1,h2,h3')?text:(text.length>110?text.slice(Math.max(0,n-30),Math.min(text.length,n+96))+'…':text),isHead:el.matches('h1,h2,h3'),pos:n})}}
 scored.sort((a,b)=>Number(b.isHead)-Number(a.isHead)||a.pos-b.pos);const short=scored.slice(0,16);
 results.innerHTML=short.length?short.map(x=>`<a href="#${x.id}" class="search-hit"><strong>${x.isHead?'SECTION':'TEXT MATCH'}</strong>${escapeHTML(x.title)}</a>`).join(''):'<span style="font-size:12px;display:block;padding:10px">No matches in the manuscript</span>';results.hidden=false;
});
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
results.addEventListener('click',e=>{if(e.target.closest('a')){results.hidden=true;$('#sidebar').classList.remove('open')}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#diagramModal').hidden=true;results.hidden=true;$('#sidebar').classList.remove('open')}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.focus();search.select()}});
let mathList=null;
$$('.copy-tex').forEach(b=>b.addEventListener('click',async()=>{try{if(!mathList)mathList=JSON.parse(document.getElementById('equationsJson').textContent);const t=mathList[Number(b.dataset.eq)]?.tex||'';await navigator.clipboard.writeText(t);note('LaTeX copied')}catch(e){note('Copy unavailable offline in this browser; original LaTeX is in source/dissertation.md')}}));
const modal=$('#diagramModal');const close=()=>{modal.hidden=true;document.body.style.overflow=''};
$$('.diagram-expand').forEach(b=>b.addEventListener('click',()=>{const url=b.dataset.image;$('#modalImage').src=url;modal.hidden=false;document.body.style.overflow='hidden'}));
$('#closeModal').addEventListener('click',close);modal.addEventListener('click',e=>{if(e.target===modal)close()});
const demo=[
 {x:190,y:133,pct:30,label:'TRACKING · SURVEY IN PROGRESS',minor:'The first part of the edge has verified observation evidence.',message:'The UAV is surveying the assigned A→B corridor. Verified coverage grows only when observation evidence is accepted.',gap:false,path:'M43 133 L538 133'},
 {x:336,y:57,pct:36,label:'DEVIATION · GEOGRAPHICAL GAP DETECTED',minor:'UAV drift caused an unverified section near the middle.',message:'A deviation can leave geographical surveying obligations incomplete even when the drone later reaches B. VECR retains confirmed work and records the missing region.',gap:true,path:'M43 133 L220 133 Q270 18 336 57'},
 {x:224,y:133,pct:36,label:'RECOVERY · RETURN TO VERIFIED FRONTIER',minor:'Resume at an admissible re-entry point with overlap.',message:'The local SwarmKit agent requests a safe recovery back toward the first unverified section. Recovery does not advance the rotor-router algorithm by itself.',gap:true,path:'M336 57 Q315 15 270 67 L224 133'},
 {x:538,y:133,pct:100,label:'EDGE VERIFIED · SURVEY OBLIGATION FULFILLED',minor:'All required intervals have accepted observation evidence.',message:'Once sufficient evidence covers the entire required region, SwarmKit can report EDGE_VERIFIED. Any gossip or rotor-router application may share or act on this report.',gap:false,path:'M224 133 L538 133'}
];
const drone=$('#droneSymbol'),path=$('#travelPath'),covered=$('#coveredPath'),gap=$('#gapPath');
let previousDrone={x:43,y:133}, droneAnimation=0;
function travelDrone(target){
 cancelAnimationFrame(droneAnimation);
 const start={...previousDrone}; const duration=1100; const begun=performance.now();
 function frame(now){const t=Math.min(1,(now-begun)/duration);const smooth=t*t*(3-2*t);
 const x=start.x+(target.x-start.x)*smooth,y=start.y+(target.y-start.y)*smooth;
 drone.setAttribute('transform',`translate(${x.toFixed(2)} ${y.toFixed(2)})`);
 if(t<1)droneAnimation=requestAnimationFrame(frame);else previousDrone={x:target.x,y:target.y};}
 if(matchMedia('(prefers-reduced-motion: reduce)').matches){drone.setAttribute('transform',`translate(${target.x} ${target.y})`);previousDrone={x:target.x,y:target.y};return;}
 droneAnimation=requestAnimationFrame(frame);
}
function showDemo(i){const x=demo[i];$$('.demo-btn').forEach((b,j)=>b.classList.toggle('active',i===j));travelDrone(x);path.setAttribute('d',x.path);covered.setAttribute('d',`M43 133 L${43+495*x.pct/100} 133`);gap.setAttribute('d',x.gap?'M221 133 L350 133':'M221 133 L221 133');$('#sceneLabel').textContent=x.label;$('#sceneSecondary').textContent=x.minor;$('#coveragePercentage').textContent=x.pct+'%';$('#coverageBar').style.width=x.pct+'%';$('#demoStatus').textContent=x.message}
$$('.demo-btn').forEach(b=>b.addEventListener('click',()=>showDemo(Number(b.dataset.step))));
showDemo(0);
// Gentle auto-progression until the reader manually selects a state.
let manual=false;$$('.demo-btn').forEach(b=>b.addEventListener('click',()=>manual=true));let k=0;
if(!matchMedia('(prefers-reduced-motion: reduce)').matches)setInterval(()=>{if(manual||document.hidden)return;const rect=$('#interactiveScene').getBoundingClientRect();if(rect.bottom<0||rect.top>innerHeight)return;k=(k+1)%4;showDemo(k)},6400);
})();
